
public interface ShapeFactory {
    Shapes.Shape createShape();
}
