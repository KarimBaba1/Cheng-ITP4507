public class ProductA1 extends AbstractProductA{
    public String getName(){return "ProductA1";}

 }
