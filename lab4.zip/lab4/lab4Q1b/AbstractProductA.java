public abstract class AbstractProductA{
    public abstract String getName();
}
