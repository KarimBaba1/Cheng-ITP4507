
public class ProductB2 extends AbstractProductB{
    public String getName(){return "ProductB2";}
}

