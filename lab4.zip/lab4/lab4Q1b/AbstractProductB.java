
public abstract class AbstractProductB{
    public abstract String getName();
}
