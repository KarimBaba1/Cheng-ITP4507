
public class ProductA2 extends AbstractProductA{
    public String getName(){return "ProductA2";}

 }
