public class ProductB1 extends AbstractProductB{
    public String getName(){return "ProductB1";}
}

