public class ConcreteProductA extends Product{
  
  public String getName(){
    return "ConcreteProductA";
  }
}
