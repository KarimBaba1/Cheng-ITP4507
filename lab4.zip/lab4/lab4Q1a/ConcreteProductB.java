public class ConcreteProductB extends Product{
  
  public String getName(){
    return "ConcreteProductB";
  }
}

