   public abstract class Product {
    
       public abstract String getName();

   } 

