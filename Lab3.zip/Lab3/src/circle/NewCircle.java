// NewCircle.java
import java.awt.Point;

public interface NewCircle {
    public double getRadius();
    public Point getCenter();
}

