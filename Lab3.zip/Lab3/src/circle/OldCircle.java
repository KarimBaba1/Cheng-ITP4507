public interface OldCircle {
	public double [] getCoeff( );
}
