// bankone/SavingAccount.java
package bankone;

public class SavingAccount extends Account {
    public SavingAccount(String accountNumber, double openingBalance) {
        super(accountNumber, openingBalance);
    }
}

